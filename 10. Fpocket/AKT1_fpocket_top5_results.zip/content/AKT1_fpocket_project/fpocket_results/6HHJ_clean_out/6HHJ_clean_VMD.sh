#!/bin/bash
vmd 6HHJ_clean_out.pdb -e 6HHJ_clean.tcl
