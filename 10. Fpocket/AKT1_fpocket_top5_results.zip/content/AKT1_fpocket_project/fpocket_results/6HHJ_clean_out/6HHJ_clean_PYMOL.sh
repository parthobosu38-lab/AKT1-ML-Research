#!/bin/bash
pymol 6HHJ_clean.pml
