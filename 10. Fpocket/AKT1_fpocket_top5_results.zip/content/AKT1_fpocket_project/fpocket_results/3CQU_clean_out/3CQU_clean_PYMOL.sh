#!/bin/bash
pymol 3CQU_clean.pml
