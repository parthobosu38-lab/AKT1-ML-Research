#!/bin/bash
vmd 3CQU_clean_out.pdb -e 3CQU_clean.tcl
