#!/bin/bash
pymol 6S9W_clean.pml
