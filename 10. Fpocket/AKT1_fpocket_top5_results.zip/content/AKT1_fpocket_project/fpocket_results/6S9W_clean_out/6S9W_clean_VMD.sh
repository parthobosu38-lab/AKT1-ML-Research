#!/bin/bash
vmd 6S9W_clean_out.pdb -e 6S9W_clean.tcl
