#!/bin/bash
vmd 3QKK_clean_out.pdb -e 3QKK_clean.tcl
