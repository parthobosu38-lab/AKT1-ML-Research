#!/bin/bash
pymol 3QKK_clean.pml
