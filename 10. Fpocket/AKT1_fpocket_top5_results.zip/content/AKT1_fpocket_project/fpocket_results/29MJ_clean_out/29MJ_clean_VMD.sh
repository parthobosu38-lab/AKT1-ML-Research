#!/bin/bash
vmd 29MJ_clean_out.pdb -e 29MJ_clean.tcl
