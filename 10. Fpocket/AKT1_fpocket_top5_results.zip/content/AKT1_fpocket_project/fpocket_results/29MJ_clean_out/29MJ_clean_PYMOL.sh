#!/bin/bash
pymol 29MJ_clean.pml
