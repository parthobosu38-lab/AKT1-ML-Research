#!/bin/bash
pymol 6CCY_clean.pml
