#!/bin/bash
vmd 6CCY_clean_out.pdb -e 6CCY_clean.tcl
