#!/bin/bash
pymol 7MYX_clean.pml
