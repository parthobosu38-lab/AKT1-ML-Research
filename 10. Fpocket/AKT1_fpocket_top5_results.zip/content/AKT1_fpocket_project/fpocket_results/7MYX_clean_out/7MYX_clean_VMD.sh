#!/bin/bash
vmd 7MYX_clean_out.pdb -e 7MYX_clean.tcl
