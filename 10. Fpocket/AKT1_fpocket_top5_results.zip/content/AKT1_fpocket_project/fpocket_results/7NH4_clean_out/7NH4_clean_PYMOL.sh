#!/bin/bash
pymol 7NH4_clean.pml
