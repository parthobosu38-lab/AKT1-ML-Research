#!/bin/bash
vmd 7NH4_clean_out.pdb -e 7NH4_clean.tcl
