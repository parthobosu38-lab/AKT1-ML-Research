#!/bin/bash
pymol 2UVM_clean.pml
