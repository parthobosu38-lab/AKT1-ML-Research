#!/bin/bash
vmd 2UVM_clean_out.pdb -e 2UVM_clean.tcl
