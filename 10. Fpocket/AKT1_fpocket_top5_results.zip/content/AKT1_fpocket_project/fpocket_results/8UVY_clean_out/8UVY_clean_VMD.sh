#!/bin/bash
vmd 8UVY_clean_out.pdb -e 8UVY_clean.tcl
