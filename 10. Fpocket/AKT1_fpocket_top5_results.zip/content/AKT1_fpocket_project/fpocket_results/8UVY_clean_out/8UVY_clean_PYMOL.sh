#!/bin/bash
pymol 8UVY_clean.pml
