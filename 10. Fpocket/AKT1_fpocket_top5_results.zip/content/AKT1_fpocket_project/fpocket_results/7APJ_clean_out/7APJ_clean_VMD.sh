#!/bin/bash
vmd 7APJ_clean_out.pdb -e 7APJ_clean.tcl
