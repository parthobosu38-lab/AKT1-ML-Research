#!/bin/bash
pymol 7APJ_clean.pml
