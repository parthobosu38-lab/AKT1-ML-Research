#!/bin/bash
vmd 3NUY_clean_out.pdb -e 3NUY_clean.tcl
