#!/bin/bash
pymol 3NUY_clean.pml
