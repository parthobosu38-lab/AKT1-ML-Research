#!/bin/bash
pymol 4EJN_clean.pml
