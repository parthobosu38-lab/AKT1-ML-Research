#!/bin/bash
vmd 4EJN_clean_out.pdb -e 4EJN_clean.tcl
