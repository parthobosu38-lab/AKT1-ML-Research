#!/bin/bash
pymol 3QKL_clean.pml
