#!/bin/bash
vmd 3QKL_clean_out.pdb -e 3QKL_clean.tcl
