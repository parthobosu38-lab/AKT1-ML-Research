#!/bin/bash
vmd 5LVP_clean_out.pdb -e 5LVP_clean.tcl
