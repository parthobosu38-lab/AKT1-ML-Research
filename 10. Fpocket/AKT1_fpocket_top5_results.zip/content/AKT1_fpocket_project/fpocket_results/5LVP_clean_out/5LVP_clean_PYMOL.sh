#!/bin/bash
pymol 5LVP_clean.pml
