#!/bin/bash
pymol 3NUN_clean.pml
