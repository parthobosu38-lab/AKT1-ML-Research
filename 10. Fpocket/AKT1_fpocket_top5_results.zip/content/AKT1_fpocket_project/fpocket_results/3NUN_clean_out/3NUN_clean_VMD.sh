#!/bin/bash
vmd 3NUN_clean_out.pdb -e 3NUN_clean.tcl
