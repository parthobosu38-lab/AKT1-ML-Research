#!/bin/bash
vmd 3NUU_clean_out.pdb -e 3NUU_clean.tcl
