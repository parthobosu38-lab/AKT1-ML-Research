#!/bin/bash
pymol 3NUU_clean.pml
