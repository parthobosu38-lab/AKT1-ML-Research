#!/bin/bash
vmd 7NH5_clean_out.pdb -e 7NH5_clean.tcl
