#!/bin/bash
pymol 7NH5_clean.pml
