#!/bin/bash
vmd 4EKL_clean_out.pdb -e 4EKL_clean.tcl
