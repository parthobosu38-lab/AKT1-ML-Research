#!/bin/bash
pymol 4EKL_clean.pml
