#!/bin/bash
pymol 6NPZ_clean.pml
