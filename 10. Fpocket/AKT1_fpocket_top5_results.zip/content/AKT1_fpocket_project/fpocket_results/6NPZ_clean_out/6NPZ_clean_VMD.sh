#!/bin/bash
vmd 6NPZ_clean_out.pdb -e 6NPZ_clean.tcl
