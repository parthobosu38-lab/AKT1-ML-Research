#!/bin/bash
vmd 3QKM_clean_out.pdb -e 3QKM_clean.tcl
