#!/bin/bash
pymol 3QKM_clean.pml
