#!/bin/bash
vmd 8UW7_clean_out.pdb -e 8UW7_clean.tcl
