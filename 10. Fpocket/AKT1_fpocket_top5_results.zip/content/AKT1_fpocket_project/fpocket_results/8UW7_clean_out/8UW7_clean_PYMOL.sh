#!/bin/bash
pymol 8UW7_clean.pml
