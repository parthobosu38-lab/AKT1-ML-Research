#!/bin/bash
vmd 3MV5_clean_out.pdb -e 3MV5_clean.tcl
