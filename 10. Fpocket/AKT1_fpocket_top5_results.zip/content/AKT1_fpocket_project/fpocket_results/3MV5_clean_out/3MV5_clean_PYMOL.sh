#!/bin/bash
pymol 3MV5_clean.pml
