#!/bin/bash
pymol 2UZR_clean.pml
