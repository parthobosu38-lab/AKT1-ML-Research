#!/bin/bash
vmd 2UZR_clean_out.pdb -e 2UZR_clean.tcl
