#!/bin/bash
pymol 3CQW_clean.pml
