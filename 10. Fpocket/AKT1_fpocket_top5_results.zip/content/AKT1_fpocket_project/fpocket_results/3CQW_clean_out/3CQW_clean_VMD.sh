#!/bin/bash
vmd 3CQW_clean_out.pdb -e 3CQW_clean.tcl
