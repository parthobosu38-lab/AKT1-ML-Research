#!/bin/bash
pymol 2UZS_clean.pml
