#!/bin/bash
vmd 2UZS_clean_out.pdb -e 2UZS_clean.tcl
