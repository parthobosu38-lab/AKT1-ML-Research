#!/bin/bash
vmd 5AAR_clean_out.pdb -e 5AAR_clean.tcl
