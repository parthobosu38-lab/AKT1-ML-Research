#!/bin/bash
pymol 5AAR_clean.pml
