#!/bin/bash
vmd 6BUU_clean_out.pdb -e 6BUU_clean.tcl
