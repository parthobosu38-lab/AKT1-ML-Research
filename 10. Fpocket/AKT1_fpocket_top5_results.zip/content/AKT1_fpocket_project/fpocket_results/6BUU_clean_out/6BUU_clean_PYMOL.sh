#!/bin/bash
pymol 6BUU_clean.pml
