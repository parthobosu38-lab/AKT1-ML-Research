#!/bin/bash
vmd 8UW2_clean_out.pdb -e 8UW2_clean.tcl
