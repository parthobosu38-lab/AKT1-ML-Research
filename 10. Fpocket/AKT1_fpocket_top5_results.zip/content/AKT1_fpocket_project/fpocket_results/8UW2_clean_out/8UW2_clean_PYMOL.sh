#!/bin/bash
pymol 8UW2_clean.pml
