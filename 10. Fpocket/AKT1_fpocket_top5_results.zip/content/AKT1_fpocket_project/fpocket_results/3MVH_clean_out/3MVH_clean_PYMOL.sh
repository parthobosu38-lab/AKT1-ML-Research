#!/bin/bash
pymol 3MVH_clean.pml
