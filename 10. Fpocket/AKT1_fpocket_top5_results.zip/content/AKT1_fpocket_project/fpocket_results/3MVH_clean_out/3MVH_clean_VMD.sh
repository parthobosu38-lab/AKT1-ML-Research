#!/bin/bash
vmd 3MVH_clean_out.pdb -e 3MVH_clean.tcl
