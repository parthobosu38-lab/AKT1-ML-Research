#!/bin/bash
vmd 4GV1_clean_out.pdb -e 4GV1_clean.tcl
