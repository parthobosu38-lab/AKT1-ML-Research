#!/bin/bash
pymol 4GV1_clean.pml
