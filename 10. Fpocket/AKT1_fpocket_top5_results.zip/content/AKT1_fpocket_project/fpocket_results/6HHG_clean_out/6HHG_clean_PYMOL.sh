#!/bin/bash
pymol 6HHG_clean.pml
