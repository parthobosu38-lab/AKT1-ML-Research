#!/bin/bash
vmd 6HHG_clean_out.pdb -e 6HHG_clean.tcl
