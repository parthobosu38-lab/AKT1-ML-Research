#!/bin/bash
vmd 8UW9_clean_out.pdb -e 8UW9_clean.tcl
