#!/bin/bash
pymol 8UW9_clean.pml
